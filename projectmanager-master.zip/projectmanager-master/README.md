This project goes with the [ReactJS Crash Course](https://www.youtube.com/watch?v=A71aqufiNtQ) YouTube video

## ReactJS Project Manager

Very simple project manager interface using React

```sh
$ npm install
```

```sh
$ npm start
```
